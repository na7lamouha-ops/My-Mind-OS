// Service worker : Trello (session Chrome), capture d'écran, téléchargements, relais vers l'offscreen.
const TRELLO = 'https://trello.com/1';

async function dsc() {
  const c = await chrome.cookies.get({ url: 'https://trello.com/', name: 'dsc' });
  if (!c) throw new Error('connecte-toi à Trello dans Chrome (trello.com)');
  return c.value;
}

async function boards() {
  const r = await fetch(`${TRELLO}/members/me/boards?filter=open&fields=name,shortLink&lists=open&list_fields=name`, { credentials: 'include' })
    .catch(() => { throw new Error('Trello injoignable — vérifie ta connexion internet'); });
  if (r.status === 401 || r.status === 403) throw new Error('connecte-toi à Trello dans Chrome (trello.com)');
  if (!r.ok) throw new Error('Trello a répondu ' + r.status);
  const j = await r.json();
  return j.map((b) => ({ id: b.id, name: b.name, shortLink: b.shortLink, lists: (b.lists || []).map((l) => ({ id: l.id, name: l.name })) }));
}

// Referer TikTok/Instagram pour les seules requêtes de l'extension
async function setRules() {
  const ext = chrome.runtime.id;
  const rule = (id, domains, ref) => ({
    id, priority: 1,
    action: { type: 'modifyHeaders', requestHeaders: [{ header: 'Referer', operation: 'set', value: ref }] },
    condition: { requestDomains: domains, initiatorDomains: [ext], resourceTypes: ['xmlhttprequest', 'other', 'media'] },
  });
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1, 2],
    addRules: [
      rule(1, ['tiktok.com', 'tiktokcdn.com', 'tiktokcdn-us.com', 'tiktokv.com', 'tiktokv.us', 'byteoversea.com', 'ibyteimg.com'], 'https://www.tiktok.com/'),
      rule(2, ['cdninstagram.com'], 'https://www.instagram.com/'),
    ],
  });
}
chrome.runtime.onStartup.addListener(setRules);
chrome.runtime.onInstalled.addListener(setRules);

async function ensureOffscreen() {
  const has = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (has.length) return;
  await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['BLOBS', 'WORKERS'], justification: 'Assembler image + son et envoyer les fichiers à Trello' });
}

const jobs = new Map(); // jobId -> {tabId, sendResponse}

chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
  (async () => {
    try {
      if (m.type === 'boards') return sendResponse({ ok: true, boards: await boards() });
      if (m.type === 'listCards') {
        const [rc, rl] = await Promise.all([
          fetch(`${TRELLO}/lists/${m.listId}/cards?fields=name,idLabels&attachments=cover&attachment_fields=previews,url`, { credentials: 'include' }),
          fetch(`${TRELLO}/boards/${m.boardId}/labels?fields=name&limit=1000`, { credentials: 'include' }),
        ]);
        if (!rc.ok || !rl.ok) throw new Error('Trello a répondu ' + (rc.ok ? rl.status : rc.status));
        const mods = Object.fromEntries((await rl.json()).filter((l) => /^MOD-\d+/.test(l.name || '')).map((l) => [l.id, l.name]));
        const cards = await rc.json();
        const out = [];
        for (let i = 0; i < cards.length; i += 12) {
          await Promise.all(cards.slice(i, i + 12).map(async (c) => {
            const a = (c.attachments || [])[0];
            const pv = a && ((a.previews || []).filter((p) => p.width >= 100).sort((x, y) => x.width - y.width)[0] || (a.previews || [])[0]);
            let img = '';
            if (pv) { try { const b = await (await fetch(pv.url, { credentials: 'include' })).blob(); img = await new Promise((r) => { const f = new FileReader(); f.onload = () => r(f.result); f.readAsDataURL(b); }); } catch (e) {} }
            const modId = (c.idLabels || []).find((id) => mods[id]);
            out.push({ id: c.id, name: c.name, img, modId: modId || '', modName: modId ? mods[modId] : '' });
          }));
        }
        out.sort((x, y) => cards.findIndex((c) => c.id === x.id) - cards.findIndex((c) => c.id === y.id));
        return sendResponse({ ok: true, cards: out });
      }
      if (m.type === 'labels') {
        const r = await fetch(`${TRELLO}/boards/${m.boardId}/labels?fields=name,color&limit=1000`, { credentials: 'include' });
        if (!r.ok) throw new Error('Trello a répondu ' + r.status);
        const mods = (await r.json()).filter((l) => /^MOD-\d+/.test(l.name || '')).map((l) => ({ id: l.id, name: l.name }))
          .sort((a, b) => b.name.localeCompare(a.name, undefined, { numeric: true }));
        return sendResponse({ ok: true, mods });
      }
      if (m.type === 'capture') {
        const dataUrl = await chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' });
        return sendResponse({ ok: true, dataUrl });
      }
      if (m.type === 'job') {
        await setRules();
        await ensureOffscreen();
        const jobId = Math.random().toString(36).slice(2);
        jobs.set(jobId, { tabId: sender.tab.id, sendResponse });
        chrome.runtime.sendMessage({ target: 'offscreen', type: 'job', jobId, dsc: await dsc(), job: m.job });
        return; // réponse envoyée à la fin du travail
      }
      // messages venant de l'offscreen
      if (m.type === 'progress') { const j = jobs.get(m.jobId); if (j) chrome.tabs.sendMessage(j.tabId, { type: 'progress', text: m.text }); return; }
      if (m.type === 'done') { const j = jobs.get(m.jobId); if (j) { jobs.delete(m.jobId); j.sendResponse(m.result); } return; }
      if (m.type === 'saveLocal') {
        const id = await chrome.downloads.download({ url: m.url, filename: 'catalogue-trello/' + m.filename, conflictAction: 'uniquify', saveAs: false });
        return sendResponse({ ok: true, id });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    }
  })();
  return true;
});

// robot « À tester → Drive »
try { importScripts('drive.js'); } catch (e) { console.error('drive.js', e); }
