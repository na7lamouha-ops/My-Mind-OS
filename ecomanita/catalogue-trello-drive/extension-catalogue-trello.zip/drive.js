// « 🧪 À tester → Drive » : toutes les minutes, les cartes posées dans la liste « À tester »
// voient leurs fichiers montés dans Drive (Mon Drive / ecomanita catalogue / <modèle>),
// vérifiés deux fois (taille à l'envoi + relecture du dossier), puis le lien est écrit sur la carte.
const DRIVE_DONE = '📁 Drive :';
let driveBusy = false;

async function driveConfig() {
  try { return await (await fetch(chrome.runtime.getURL('config.json'))).json(); } catch (e) { return {}; }
}
const b64 = (buf) => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };

async function callDrive(url, body) {
  const r = await fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) });
  const t = await r.text();
  try { return JSON.parse(t); } catch (e) { throw new Error('Drive : réponse illisible (' + r.status + ') — connecte-toi au bon compte Google dans Chrome'); }
}

async function trelloWrite(method, path, obj) {
  const f = new FormData(); for (const [k, v] of Object.entries(obj)) f.append(k, v); f.append('dsc', await dsc());
  const r = await fetch(`${TRELLO}${path}`, { method, body: f, credentials: 'include' });
  if (!r.ok) throw new Error('Trello ' + r.status);
  return r.json();
}

async function processTester() {
  if (driveBusy) return; driveBusy = true;
  const log = [];
  try {
    const cfg = await driveConfig();
    if (!cfg.driveUrl || !cfg.board) return;
    const b = await (await fetch(`${TRELLO}/boards/${cfg.board}?fields=id&lists=open&list_fields=name&labels=all&label_fields=name&labels_limit=1000`, { credentials: 'include' })).json();
    const list = (b.lists || []).find((l) => /tester/i.test(l.name)); if (!list) return;
    const mods = Object.fromEntries((b.labels || []).filter((l) => /^MOD-\d+/.test(l.name || '')).map((l) => [l.id, l.name.split(' ')[0]]));
    const cards = await (await fetch(`${TRELLO}/lists/${list.id}/cards?fields=name,desc,idLabels&attachments=true&attachment_fields=name,bytes,isUpload,mimeType,url`, { credentials: 'include' })).json();
    const st = (await chrome.storage.local.get('driveTries')).driveTries || {};
    for (const c of cards) {
      if ((c.desc || '').includes(DRIVE_DONE)) continue;
      if ((st[c.id] || 0) >= 3) continue;
      const model = (c.idLabels || []).map((id) => mods[id]).find(Boolean) || (c.name.match(/MOD-\d+/) || [])[0] || c.name.split(' ')[0].replace(/[^\w-]/g, '') || c.id.slice(-6);
      const files = (c.attachments || []).filter((a) => a.isUpload && a.name !== 'capture.png');
      const hasVideo = files.some((a) => /video|mp4/i.test((a.mimeType || '') + a.name));
      const ig = ((c.desc || '') + ' ' + (c.attachments || []).map((a) => a.url || '').join(' ')).match(/https:\/\/www\.instagram\.com\/(?:p|reel|reels|tv)\/[A-Za-z0-9_-]+/);
      const ref = c.name.split(' ')[0].replace(/[^\w-]/g, '');
      try {
        let sent = [];
        if (!hasVideo && ig) {
          // carte du catalogue : on va chercher la vraie vidéo / les vraies photos de la publication
          await ensureOffscreen();
          const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'igToDrive', postUrl: ig[0], model, prefix: `${model}-${ref}`, driveUrl: cfg.driveUrl });
          if (!r || !r.ok) { const e = new Error(r ? r.error : 'pas de réponse'); e.retry = r && r.retry; throw e; }
          sent = r.sent;
          await new Promise((res) => setTimeout(res, 4000));
        } else {
        if (!files.length) throw new Error('aucun fichier sur la carte');
        for (const a of files) {
          const r = await fetch(a.url, { credentials: 'include' });
          if (!r.ok) throw new Error(`${a.name} : téléchargement Trello ${r.status}`);
          const buf = await r.arrayBuffer();
          if (a.bytes && buf.byteLength !== a.bytes) throw new Error(`${a.name} : taille Trello différente`);
          const name = `${model}-${a.name}`;
          const res = await callDrive(cfg.driveUrl, { action: 'upload', model, fileName: name, mime: a.mimeType || 'application/octet-stream', b64: b64(buf) });
          if (!res.ok) throw new Error(`${a.name} : ${res.error}`);
          if (res.size !== buf.byteLength) throw new Error(`${a.name} : taille différente dans Drive`);
          sent.push({ name, size: buf.byteLength });
        }
        }
        // 2e méthode : relire le dossier Drive
        const ls = await callDrive(cfg.driveUrl, { action: 'list', model });
        if (!ls.ok) throw new Error('relecture Drive : ' + ls.error);
        const miss = sent.filter((s) => !ls.files.some((f) => f.name === s.name && f.size === s.size));
        if (miss.length) throw new Error('relu dans Drive : manque ' + miss.map((m) => m.name).join(', '));
        await trelloWrite('PUT', `/cards/${c.id}`, { desc: `${DRIVE_DONE} ${ls.folderUrl}\n✅ ${sent.length} fichier(s) vérifiés dans Drive (${model}) — vidéos : ${sent.filter((x) => x.video || /\.mp4$/i.test(x.name)).length}\n\n` + (c.desc || '') });
        await trelloWrite('POST', `/cards/${c.id}/attachments`, { url: ls.folderUrl, name: `📁 Dossier Drive ${model}` });
        // le lien part vers la chaîne : une TÂCHE dans le bureau ecom manita (sa porte normale, /api/taches),
        // avec « besoin de ton OK » coché : rien ne se lance sans l'accord du marchand
        let chaine = 'bureau non réglé';
        if (cfg.bureau) {
          try {
            const texte = `🧪 موديل للتيست جا من Trello : ${model}\nالكارطة : ${c.name}\nرابط Drive : ${ls.folderUrl}\nابدا السلسلة تاع « عندي موديل للتيست » بهاذ الرابط، وسقسيني الأسئلة تاعك في تيليغرام.`;
            const rb = await fetch(cfg.bureau.replace(/\/$/, '') + '/api/taches', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ texte, modele: 'sonnet', besoinOk: true }) });
            chaine = rb.ok ? 'tâche envoyée au bureau (attend ton OK)' : 'bureau ' + rb.status;
          } catch (e) { chaine = 'bureau éteint'; }
        }
        await trelloWrite('POST', `/cards/${c.id}/actions/comments`, { text: `📁 Dossier Drive prêt : ${ls.folderUrl}\n🚀 Chaîne : ${chaine}` });
        delete st[c.id];
        log.push(`${c.name.slice(0, 40)} → OK (${chaine})`);
      } catch (e) {
        if (e.retry) { log.push(`${c.name.slice(0, 40)} → ${e.message}`); break; }
        st[c.id] = (st[c.id] || 0) + 1;
        if (st[c.id] >= 3) { try { await trelloWrite('POST', `/cards/${c.id}/actions/comments`, { text: '⚠️ Drive : ' + (e.message || e) + ' — 3 essais ratés, je m\'arrête. Corrige puis enlève et remets la carte.' }); } catch (x) {} }
        log.push(`${c.name.slice(0, 40)} → ${e.message || e}`);
      }
    }
    await chrome.storage.local.set({ driveTries: st, driveLast: { at: new Date().toISOString(), log } });
  } catch (e) {
    await chrome.storage.local.set({ driveLast: { at: new Date().toISOString(), log: ['ERREUR ' + (e.message || e)] } });
  } finally { driveBusy = false; }
}

chrome.alarms.create('drive', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'drive') processTester(); });
