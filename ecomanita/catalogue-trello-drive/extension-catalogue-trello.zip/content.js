// Panneau « Catalogue → Trello » + lecture des médias de la publication ouverte.
(() => {
  if (window.__catPanel) return;
  window.__catPanel = true;
  const host = location.hostname;
  const PLAT = host.includes('instagram') ? 'IG' : host.includes('tiktok') ? 'TT' : 'FB';

  // ---------- Panneau ----------
  const root = document.createElement('div');
  root.id = 'cat-trello-panel';
  root.attachShadow({ mode: 'open' }).innerHTML = `
  <style>
    .box{position:fixed;left:12px;bottom:12px;z-index:2147483647;background:#fff;color:#172b4d;border-radius:12px;
      box-shadow:0 4px 18px rgba(0,0,0,.25);font:13px/1.35 -apple-system,Segoe UI,Roboto,sans-serif;width:230px;padding:10px}
    .row{display:flex;gap:6px;margin-top:6px}
    select{width:100%;padding:5px;border:1px solid #c1c7d0;border-radius:6px;font:inherit}
    button{flex:1;border:0;border-radius:8px;padding:9px 4px;font:600 13px inherit;cursor:pointer;color:#fff}
    .mode{background:#dfe1e6;color:#172b4d;padding:6px 2px;font-size:12px}.mode.on{background:#5aac44;color:#fff}
    .hint{font-size:11px;color:#5e6c84;margin-top:6px}
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;max-height:230px;overflow-y:auto;margin-top:4px}
    .t{position:relative;cursor:pointer;border:2px solid transparent;border-radius:6px;overflow:hidden;height:92px;background:#f4f5f7}
    .t img{width:100%;height:100%;object-fit:cover;display:block}
    .t b{position:absolute;left:0;right:0;bottom:0;background:#000b;color:#fff;font:600 9px sans-serif;padding:1px 2px;white-space:nowrap;overflow:hidden}
    .t.sel{border-color:#5aac44}
    .cap{background:#0079bf}.vid{background:#d6336c}button:disabled{opacity:.5;cursor:wait}
    .cats{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
    .chip{border:1px solid #c1c7d0;border-radius:12px;padding:3px 7px;font-size:12px;cursor:pointer;user-select:none}
    .chip.on{background:#0079bf;color:#fff;border-color:#0079bf}
    .st{margin-top:6px;font-size:12px;min-height:16px;word-break:break-word}
    .top{display:flex;justify-content:space-between;align-items:center;font-weight:700}
    .x{background:none;color:#5e6c84;flex:0;padding:0 4px;font-size:15px}
    .mini{position:fixed;left:12px;bottom:12px;z-index:2147483647;background:#0079bf;color:#fff;border-radius:50%;
      width:40px;height:40px;border:0;font-size:18px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,.3)}
  </style>
  <div class="box" id="box">
    <div class="top"><span>📌 Catalogue Trello</span><button class="x" id="hide" title="Réduire">–</button></div>
    <div class="row"><select id="board"><option>Chargement…</option></select></div>
    <div class="cats" id="cats"></div>
    <div class="row"><select id="list"></select></div>
    <div class="row"><button class="mode on" id="mNew">🆕 Nouveau modèle</button><button class="mode" id="mOld">🔁 Existe déjà</button></div>
    <div id="modRow" style="display:none"><div class="hint" id="modHint"></div><div class="grid" id="grid"></div></div>
    <div class="row"><button class="cap" id="cap">📸 Capture + lien</button><button class="vid" id="vid">🎬 Vidéo</button></div>
    <div class="st" id="st"></div>
  </div>
  <button class="mini" id="mini" style="display:none" title="Catalogue Trello">📌</button>`;
  document.documentElement.appendChild(root);
  const $ = (id) => root.shadowRoot.getElementById(id);
  const say = (t) => ($('st').textContent = t);
  const busy = (b) => { $('cap').disabled = b; $('vid').disabled = b; };
  $('hide').onclick = () => { $('box').style.display = 'none'; $('mini').style.display = 'block'; };
  $('mini').onclick = () => { $('box').style.display = 'block'; $('mini').style.display = 'none'; };

  const send = (msg) => new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r || { ok: false, error: chrome.runtime.lastError?.message || 'pas de réponse' })));

  let boards = [];
  async function loadBoards() {
    const r = await send({ type: 'boards' });
    if (!r.ok) { $('board').innerHTML = '<option>Trello non connecté</option>'; say('⚠️ ' + r.error); return; }
    boards = r.boards;
    const saved = await chrome.storage.local.get(['boardId', 'listId']);
    const def = boards.find((b) => b.id === saved.boardId) || boards.find((b) => false) || boards[0];
    $('board').innerHTML = boards.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join('');
    $('board').value = def.id;
    fillLists(def.id, saved.listId);
  }
  function fillLists(boardId, listId) {
    const b = boards.find((x) => x.id === boardId);
    $('list').innerHTML = (b?.lists || []).map((l) => `<option value="${l.id}">${esc(l.name)}</option>`).join('');
    if (listId && b?.lists.some((l) => l.id === listId)) $('list').value = listId;
    // catégories du catalogue en boutons (un clic = la liste où va la carte)
    const cats = (b?.lists || []).filter((l) => /tester|Hijab|Sortie|Soir|Tarz|Pyjama|Maison|Classic|Homme|Enfant/i.test(l.name));
    $('cats').innerHTML = cats.map((l) => `<span class="chip" data-id="${l.id}">${esc(l.name)}</span>`).join('');
    $('cats').querySelectorAll('.chip').forEach((c) => (c.onclick = () => { $('list').value = c.dataset.id; markChip(); chrome.storage.local.set({ boardId, listId: c.dataset.id }); if (modMode === 'old') loadMods(); }));
    markChip();
    chrome.storage.local.set({ boardId, listId: $('list').value });
  }
  const markChip = () => $('cats').querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', c.dataset.id === $('list').value));
  let modMode = 'new';
  const setMode = (m) => { modMode = m; $('mNew').classList.toggle('on', m === 'new'); $('mOld').classList.toggle('on', m === 'old'); $('modRow').style.display = m === 'old' ? 'block' : 'none'; if (m === 'old') loadMods(); };
  $('mNew').onclick = () => setMode('new');
  $('mOld').onclick = () => setMode('old');
  let picked = null;
  async function loadMods() {
    picked = null;
    const listName = $('list').selectedOptions[0]?.textContent || '';
    $('modHint').textContent = 'Chargement des modèles de « ' + listName + ' »…';
    $('grid').innerHTML = '';
    const r = await send({ type: 'listCards', listId: $('list').value, boardId: $('board').value });
    if (!r.ok) { $('modHint').textContent = '⚠️ ' + r.error; return; }
    $('modHint').textContent = r.cards.length ? `Clique sur le modèle déjà présent dans « ${listName} » (${r.cards.length})` : `Aucune carte dans « ${listName} » — choisis une autre catégorie ou « Nouveau modèle »`;
    $('grid').innerHTML = r.cards.map((c, i) => `<div class="t" data-i="${i}" title="${esc(c.name)}">${c.img ? `<img src="${c.img}">` : ''}<b>${esc(c.modName ? c.modName.split(' ')[0] : c.name.split(' ')[0])}</b></div>`).join('');
    $('grid').querySelectorAll('.t').forEach((el) => (el.onclick = () => {
      $('grid').querySelectorAll('.t').forEach((x) => x.classList.remove('sel')); el.classList.add('sel');
      picked = r.cards[+el.dataset.i];
      $('modHint').textContent = '✅ ' + (picked.modName || picked.name);
    }));
  }
  $('board').onchange = () => { fillLists($('board').value); if (modMode === 'old') loadMods(); };
  $('list').onchange = () => { markChip(); chrome.storage.local.set({ boardId: $('board').value, listId: $('list').value }); if (modMode === 'old') loadMods(); };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  chrome.runtime.onMessage.addListener((m) => { if (m.type === 'progress') say(m.text); });

  async function run(mode) {
    const listId = $('list').value;
    if (!listId) return say('⚠️ Choisis une liste Trello');
    if (modMode === 'old' && !picked) return say('⚠️ Clique d\'abord sur le modèle qui existe déjà');
    busy(true);
    try {
      say('Lecture de la publication…');
      const info = await readPost(mode === 'video');
      if (mode === 'video' && !info.media.length) throw new Error('aucune vidéo/photo trouvée — ouvre la publication elle-même');
      // capture sans le panneau
      root.style.display = 'none';
      await new Promise((r) => setTimeout(r, 180));
      const shot = await send({ type: 'capture' });
      root.style.display = '';
      if (!shot.ok) throw new Error('capture : ' + shot.error);
      say('Envoi vers Trello…');
      const r = await send({ type: 'job', job: { mode, listId, boardId: $('board').value, modMode, modLabelId: modMode === 'old' ? picked.modId : '', modLabelName: modMode === 'old' ? picked.modName : '', sameCardId: modMode === 'old' ? picked.id : '', sameCardName: modMode === 'old' ? picked.name : '', shot: shot.dataUrl, ...info } });
      if (!r.ok) throw new Error(r.error);
      say(r.report);
    } catch (e) {
      root.style.display = '';
      const msg = String(e.message || e);
      say(/context invalidated/i.test(msg) ? '🔄 Extension mise à jour : appuie sur F5 pour recharger la page' : '❌ ' + msg);
    } finally { busy(false); }
  }
  $('cap').onclick = () => run('capture');
  $('vid').onclick = () => run('video');

  // ---------- Lecture des publications ----------
  const visibleVideo = () => {
    const vs = [...document.querySelectorAll('video')].filter((v) => { const r = v.getBoundingClientRect(); return r.width > 50 && r.bottom > 0 && r.top < innerHeight; });
    return vs.find((v) => !v.paused) || vs[0] || null;
  };

  async function readPost(wantMedia) {
    if (PLAT === 'IG') return readIG(wantMedia);
    if (PLAT === 'TT') return readTT(wantMedia);
    return readFB(wantMedia);
  }

  // Instagram : API web officielle de la page (celle qu'Instagram utilise lui-même)
  async function readIG(wantMedia) {
    let code = location.pathname.match(/\/(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/)?.[1];
    if (!code) {
      const v = visibleVideo();
      const a = v?.closest('article')?.querySelector('a[href*="/p/"],a[href*="/reel/"]');
      code = a?.getAttribute('href')?.match(/\/(?:p|reel)\/([A-Za-z0-9_-]+)/)?.[1];
    }
    if (!code) throw new Error('ouvre la publication (lien /p/ ou /reel/)');
    const url = `https://www.instagram.com/${location.pathname.includes('/reel') ? 'reel' : 'p'}/${code}/`;
    const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let id = 0n; for (const c of code.slice(0, 11)) id = id * 64n + BigInt(A.indexOf(c));
    const r = await fetch(`/api/v1/media/${id}/info/`, { credentials: 'include', headers: { 'X-IG-App-ID': '936619743392459' } });
    if (!r.ok) throw new Error('Instagram a répondu ' + r.status);
    const it = (await r.json()).items?.[0];
    if (!it) throw new Error('publication introuvable');
    const items = it.media_type === 8 ? it.carousel_media || [] : [it];
    const media = [];
    if (wantMedia) items.forEach((m, i) => {
      const n = items.length > 1 ? `_${i + 1}` : '';
      if (m.media_type === 2) media.push({ ...igVideo(m), name: `IG_${code}${n}.mp4` });
      else { const c = (m.image_versions2?.candidates || []).slice().sort((a, b) => b.width - a.width)[0]; if (c) media.push({ kind: 'file', url: c.url, name: `IG_${code}${n}.jpg`, mime: 'image/jpeg', height: c.height }); }
    });
    return { platform: 'Instagram', url, author: it.user?.username || '', caption: it.caption?.text || '', media };
  }
  function igVideo(m) {
    const prog = (m.video_versions || []).slice().sort((a, b) => b.height - a.height)[0];
    let v = null, a = null;
    if (m.video_dash_manifest) {
      const d = new DOMParser().parseFromString(m.video_dash_manifest, 'text/xml');
      const reps = [...d.querySelectorAll('Representation')].map((r) => ({
        mime: r.getAttribute('mimeType') || r.parentNode.getAttribute('mimeType') || '',
        codecs: r.getAttribute('codecs') || r.parentNode.getAttribute('codecs') || '',
        h: +r.getAttribute('height') || 0, bw: +r.getAttribute('bandwidth') || 0, url: r.querySelector('BaseURL')?.textContent,
      })).filter((x) => x.url);
      v = reps.filter((x) => x.mime.startsWith('video')).sort((x, y) => y.h - x.h || (y.codecs.startsWith('avc') - x.codecs.startsWith('avc')) || y.bw - x.bw)[0];
      a = reps.filter((x) => x.mime.startsWith('audio')).sort((x, y) => y.bw - x.bw)[0];
    }
    if (v && a && (!prog || v.h > prog.height)) return { kind: 'merge', videoUrl: v.url, audioUrl: a.url, height: v.h, mime: 'video/mp4' };
    if (prog) return { kind: 'file', url: prog.url, height: prog.height, mime: 'video/mp4' };
    throw new Error('vidéo introuvable');
  }

  // TikTok : infos gardées par tiktok-hook.js à partir de ce que TikTok charge
  function ttItem(id) {
    return new Promise((res) => {
      const reqId = Math.random().toString(36).slice(2);
      const h = (e) => { if (e.source === window && e.data?.__cat === 'tt-item' && e.data.reqId === reqId) { removeEventListener('message', h); res(e.data.item); } };
      addEventListener('message', h);
      postMessage({ __cat: 'tt-get', id, reqId }, '*');
      setTimeout(() => { removeEventListener('message', h); res(null); }, 1500);
    });
  }
  async function readTT(wantMedia) {
    let id = location.pathname.match(/\/(?:video|photo)\/(\d+)/)?.[1];
    if (!id) {
      let el = visibleVideo();
      while (el && !id) { id = (el.id || '').match(/(\d{15,})/)?.[1] || el.querySelector?.('a[href*="/video/"]')?.getAttribute('href')?.match(/\/video\/(\d+)/)?.[1]; el = el.parentElement; }
    }
    if (!id) throw new Error('ouvre la vidéo TikTok');
    const it = await ttItem(id);
    const author = it?.author || location.pathname.match(/\/@([^/]+)/)?.[1] || '';
    const url = `https://www.tiktok.com/@${author}/video/${id}`;
    const media = [];
    if (wantMedia) {
      if (!it) throw new Error('infos vidéo pas encore chargées — fais défiler ou recharge la page puis réessaie');
      if (it.images.length) it.images.forEach((u, i) => media.push({ kind: 'file', url: u, name: `TT_${id}_${i + 1}.jpg`, mime: 'image/jpeg' }));
      else {
        const best = it.video.bitrateInfo.slice().sort((a, b) => (b.PlayAddr?.Height || 0) - (a.PlayAddr?.Height || 0) || b.Bitrate - a.Bitrate)[0];
        const urls = best ? best.PlayAddr.UrlList : [it.video.playAddr].filter(Boolean);
        if (!urls.length) throw new Error('lien vidéo introuvable');
        media.push({ kind: 'file', urls, name: `TT_${id}.mp4`, mime: 'video/mp4', height: best?.PlayAddr?.Height || it.video.height });
      }
    }
    return { platform: 'TikTok', url, author, caption: it?.desc || '', media };
  }

  // Facebook : liens présents dans le code de la page
  async function readFB(wantMedia) {
    const vid = location.href.match(/\/(?:reel|videos|watch\/?\?v=|v=)\/?(\d{6,})/)?.[1] || new URL(location.href).searchParams.get('v');
    const url = location.href.split('#')[0];
    const media = [];
    if (wantMedia) {
      let found = vid && fbFind(document.documentElement.innerHTML, vid);
      if (!found && vid) { const t = await fetch(location.href, { credentials: 'include' }).then((r) => r.text()).catch(() => ''); found = fbFind(t, vid); }
      if (!found) throw new Error('vidéo Facebook introuvable — ouvre la vidéo (lien /reel/ ou /videos/)');
      media.push({ ...found, name: `FB_${vid}.mp4`, mime: 'video/mp4' });
    }
    const author = document.querySelector('meta[property="og:title"]')?.content || document.title.replace(/\s*\|\s*Facebook.*/, '');
    return { platform: 'Facebook', url, author, caption: document.querySelector('meta[property="og:description"]')?.content || '', media };
  }
  function fbFind(html, vid) {
    if (!html) return null;
    const anchors = [...html.matchAll(new RegExp(`"(?:id|video_id|videoId)":"${vid}"`, 'g'))].map((m) => m.index);
    if (!anchors.length) return null;
    const near = (i) => Math.min(...anchors.map((a) => Math.abs(a - i)));
    const un = (s) => { try { return JSON.parse('"' + s + '"'); } catch (e) { return null; } };
    // progressif (vidéo + son)
    let prog = null;
    for (const k of ['browser_native_hd_url', 'playable_url_quality_hd', 'browser_native_sd_url', 'playable_url']) {
      const ms = [...html.matchAll(new RegExp(`"${k}":"((?:[^"\\\\]|\\\\.)+)"`, 'g'))];
      const m = ms.sort((a, b) => near(a.index) - near(b.index))[0];
      if (m && near(m.index) < 60000) { prog = { url: un(m[1]), hd: /hd/.test(k), d: near(m.index) }; break; }
    }
    // DASH (image et son séparés)
    let best = null;
    for (const m of html.matchAll(/"representations":\[/g)) {
      const d = near(m.index); if (d > 60000) continue;
      const arr = sliceArray(html, m.index + 18); if (!arr) continue;
      let reps; try { reps = JSON.parse(arr); } catch (e) { continue; }
      const v = reps.filter((r) => /video/.test(r.mime_type || '')).sort((a, b) => (b.height || 0) - (a.height || 0) || (b.bandwidth || 0) - (a.bandwidth || 0))[0];
      const a = reps.filter((r) => /audio/.test(r.mime_type || '')).sort((x, y) => (y.bandwidth || 0) - (x.bandwidth || 0))[0];
      if (v && (!best || d < best.d)) best = { v, a, d };
    }
    if (best?.v && best.a && (!prog || !prog.hd || (best.v.height || 0) >= 1080)) return { kind: 'merge', videoUrl: best.v.base_url, audioUrl: best.a.base_url, height: best.v.height };
    if (prog?.url) return { kind: 'file', url: prog.url };
    return null;
  }
  function sliceArray(s, start) {
    let depth = 0, inStr = false;
    for (let i = start; i < s.length && i < start + 200000; i++) {
      const c = s[i];
      if (inStr) { if (c === '\\') i++; else if (c === '"') inStr = false; continue; }
      if (c === '"') inStr = true; else if (c === '[') depth++; else if (c === ']') { depth--; if (!depth) return s.slice(start, i + 1); }
    }
    return null;
  }

  loadBoards();
})();
