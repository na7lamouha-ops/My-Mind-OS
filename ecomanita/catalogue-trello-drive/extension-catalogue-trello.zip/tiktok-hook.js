// Monde de la page TikTok : garde en mémoire les infos vidéo que TikTok charge lui-même,
// pour que l'extension retrouve le lien de la meilleure qualité (la page vidéo directe répond 403).
(() => {
  if (window.__catTT) return;
  const cache = (window.__catTT = new Map());
  const keep = (o) => {
    const v = o.video || {};
    cache.set(String(o.id), {
      id: String(o.id),
      author: o.author?.uniqueId || o.author || '',
      desc: o.desc || '',
      video: { height: v.height, width: v.width, playAddr: v.playAddr, downloadAddr: v.downloadAddr, bitrateInfo: v.bitrateInfo || [] },
      images: (o.imagePost?.images || []).map((i) => i.imageURL?.urlList?.[0]).filter(Boolean),
    });
  };
  const walk = (o, d = 0) => {
    if (!o || typeof o !== 'object' || d > 9) return;
    if (o.id && (o.video?.playAddr || o.video?.bitrateInfo || o.imagePost)) keep(o);
    for (const k in o) walk(o[k], d + 1);
  };
  const isApi = (u) => /\/api\//.test(u || '');
  const of = window.fetch;
  window.fetch = async function (...a) {
    const r = await of.apply(this, a);
    try {
      const u = String(a[0]?.url || a[0]);
      if (isApi(u)) r.clone().json().then(walk).catch(() => {});
    } catch (e) {}
    return r;
  };
  const oo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u) {
    this.__catU = String(u);
    this.addEventListener('load', () => {
      try {
        if (isApi(this.__catU) && (this.responseType === '' || this.responseType === 'text')) walk(JSON.parse(this.responseText));
        else if (isApi(this.__catU) && this.responseType === 'json') walk(this.response);
      } catch (e) {}
    });
    return oo.apply(this, arguments);
  };
  const readInitial = () => {
    try {
      const s = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
      if (s) walk(JSON.parse(s.textContent));
    } catch (e) {}
  };
  document.addEventListener('DOMContentLoaded', readInitial);
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.__cat !== 'tt-get') return;
    readInitial();
    window.postMessage({ __cat: 'tt-item', reqId: e.data.reqId, item: cache.get(String(e.data.id)) || null }, '*');
  });
})();
