// Offscreen : télécharge, assemble (ffmpeg.wasm), VÉRIFIE, envoie à Trello, vérifie sur Trello.
const TRELLO = 'https://trello.com/1';
let ff = null, ffLog = [];

async function ffmpeg() {
  if (ff) return ff;
  const { FFmpeg } = FFmpegWASM;
  ff = new FFmpeg();
  ff.on('log', ({ message }) => ffLog.push(message));
  await ff.load({
    coreURL: chrome.runtime.getURL('ffmpeg/ffmpeg-core.js'),
    wasmURL: chrome.runtime.getURL('ffmpeg/ffmpeg-core.wasm'),
  });
  return ff;
}

// Lit les pistes d'un fichier avec ffmpeg (méthode 1)
async function probe(bytes, ext) {
  const f = await ffmpeg();
  const name = 'p_' + Date.now() + '.' + ext;
  await f.writeFile(name, bytes);
  ffLog = [];
  try { await f.exec(['-hide_banner', '-i', name]); } catch (e) {}
  await f.deleteFile(name).catch(() => {});
  const log = ffLog.join('\n');
  const vm = log.match(/Stream #\S+.*Video: (\w+).*?, (\d{2,5})x(\d{2,5})/);
  const d = log.match(/Duration: (\d+):(\d+):([\d.]+)/);
  return {
    video: vm ? { codec: vm[1], w: +vm[2], h: +vm[3] } : null,
    audio: /Stream #\S+.*Audio:/.test(log),
    duration: d ? +d[1] * 3600 + +d[2] * 60 + +d[3] : 0,
  };
}

// Méthode 2 : le navigateur ouvre vraiment le fichier
function browserCheck(blob, isVideo) {
  return new Promise((res) => {
    const u = URL.createObjectURL(blob);
    const done = (r) => { URL.revokeObjectURL(u); res(r); };
    if (!isVideo) {
      createImageBitmap(blob).then((b) => done({ ok: b.width > 0, w: b.width, h: b.height })).catch(() => done({ ok: false }));
      return;
    }
    const v = document.createElement('video');
    v.muted = true; v.preload = 'metadata';
    v.onloadedmetadata = () => done({ ok: v.duration > 0 && v.videoHeight > 0, h: v.videoHeight, duration: v.duration });
    v.onerror = () => done({ ok: false });
    setTimeout(() => done({ ok: false, timeout: true }), 15000);
    v.src = u;
  });
}

async function getBlob(urls) {
  let last;
  for (const u of [].concat(urls)) {
    try {
      const r = await fetch(u, { credentials: 'include' });
      if (!r.ok) { last = 'HTTP ' + r.status; continue; }
      const b = await r.blob();
      if (b.size > 1000) return b;
      last = 'fichier vide';
    } catch (e) { last = String(e); }
  }
  throw new Error('téléchargement impossible (' + last + ')');
}

async function merge(vBlob, aBlob) {
  const f = await ffmpeg();
  await f.writeFile('v.mp4', new Uint8Array(await vBlob.arrayBuffer()));
  await f.writeFile('a.mp4', new Uint8Array(await aBlob.arrayBuffer()));
  ffLog = [];
  const code = await f.exec(['-hide_banner', '-y', '-i', 'v.mp4', '-i', 'a.mp4', '-map', '0:v:0', '-map', '1:a:0', '-c', 'copy', '-movflags', '+faststart', 'out.mp4']);
  if (code !== 0) throw new Error('assemblage échoué : ' + ffLog.slice(-3).join(' | '));
  const out = await f.readFile('out.mp4');
  await Promise.all(['v.mp4', 'a.mp4', 'out.mp4'].map((n) => f.deleteFile(n).catch(() => {})));
  return new Blob([out], { type: 'video/mp4' });
}

async function trello(path, form, dsc) {
  form.append('dsc', dsc);
  const r = await fetch(TRELLO + path, { method: 'POST', body: form, credentials: 'include' });
  const t = await r.text();
  if (!r.ok) throw Object.assign(new Error(`Trello ${r.status} : ${t.slice(0, 120)}`), { status: r.status });
  return JSON.parse(t);
}
const fd = (o) => { const f = new FormData(); for (const [k, v] of Object.entries(o)) if (Array.isArray(v)) f.append(k, v[0], v[1]); else f.append(k, v); return f; };

const saveLocal = (blob, filename) => new Promise((res) => {
  const url = URL.createObjectURL(blob);
  chrome.runtime.sendMessage({ type: 'saveLocal', url, filename }, (r) => { setTimeout(() => URL.revokeObjectURL(url), 120000); res(r?.ok); });
});

async function runJob({ jobId, dsc, job }) {
  const say = (text) => chrome.runtime.sendMessage({ type: 'progress', jobId, text });
  const lines = [];
  const date = new Date().toLocaleDateString('fr-FR');
  const short = (job.caption || '').replace(/\s+/g, ' ').trim().slice(0, 50);
  const name = `${job.platform} · @${job.author || '?'}${short ? ' · ' + short : ''}`;
  const desc = `🔗 ${job.url}\n\n${(job.caption || '').slice(0, 1500)}\n\n— ajouté le ${date}`;

  // ---- modèle (tracking) : existant ou nouveau ----
  let modId = job.modLabelId, modName = job.modLabelName;
  if ((job.modMode === 'new' || (job.modMode === 'old' && !modId)) && job.boardId) {
    say('Nouveau numéro de modèle…');
    const r0 = await fetch(`${TRELLO}/boards/${job.boardId}/labels?fields=name&limit=1000`, { credentials: 'include' });
    const used = (await r0.json()).map((l) => +((l.name || '').match(/^MOD-(\d+)/) || [])[1] || 0);
    const next = 'MOD-' + String(Math.max(0, ...used) + 1).padStart(3, '0');
    const lab = await trello('/labels', fd({ idBoard: job.boardId, name: `${next} · ${job.author ? '@' + job.author : 'nouveau'}`, color: 'black' }), dsc);
    modId = lab.id; modName = lab.name;
  }
  const modShort = (modName || '').split(' ')[0];

  say('Création de la carte…');
  const card = await trello('/cards', fd({ idList: job.listId, name: (modShort ? modShort + ' · ' : '') + name, desc: (modShort ? `🧷 Modèle : ${modName}\n` : '') + desc, pos: 'top', ...(modId ? { idLabels: modId } : {}) }), dsc);
  if (modId && !(card.idLabels || []).includes(modId)) throw new Error('étiquette du modèle non posée sur la carte');
  if (job.modMode === 'old' && job.sameCardId && !job.modLabelId) {
    // la carte d'origine n'avait pas encore de numéro : on lui pose le même
    await trello(`/cards/${job.sameCardId}/idLabels`, fd({ value: modId }), dsc);
    const chk = await (await fetch(`${TRELLO}/cards/${job.sameCardId}?fields=idLabels`, { credentials: 'include' })).json();
    if (!(chk.idLabels || []).includes(modId)) throw new Error('numéro du modèle non posé sur la carte d\'origine');
  }
  lines.push('🧷 ' + (modShort || 'sans modèle') + (job.modMode === 'new' ? ' (nouveau)' : ' (même modèle que ' + (job.sameCardName || '').split(' ')[0] + ')'));

  say('Capture d\'écran…');
  const shot = await (await fetch(job.shot)).blob();
  const sAtt = await trello(`/cards/${card.id}/attachments`, fd({ file: [shot, 'capture.png'], name: 'capture.png', mimeType: 'image/png', setCover: 'true' }), dsc);
  if (sAtt.bytes !== shot.size) throw new Error('capture envoyée mais taille différente sur Trello');
  await trello(`/cards/${card.id}/attachments`, fd({ url: job.url, name: 'Lien de la publication' }), dsc);
  lines.push('📸 capture + 🔗 lien');

  const expected = [{ name: 'capture.png', bytes: shot.size }];
  if (job.mode === 'video') {
    let i = 0;
    for (const m of job.media) {
      i++;
      const isVideo = m.mime === 'video/mp4';
      say(`Téléchargement ${i}/${job.media.length}…`);
      let blob;
      if (m.kind === 'merge') {
        const [v, a] = await Promise.all([getBlob(m.videoUrl), getBlob(m.audioUrl)]);
        say(`Assemblage image + son ${i}/${job.media.length}…`);
        blob = await merge(v, a);
      } else blob = await getBlob(m.urls || m.url);

      // ---- double vérification du fichier ----
      say(`Vérification ${i}/${job.media.length}…`);
      const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
      const magicOk = isVideo ? String.fromCharCode(...head.slice(4, 8)) === 'ftyp' : head[0] === 0xff && head[1] === 0xd8 || head[0] === 0x89 || String.fromCharCode(...head.slice(8, 12)) === 'WEBP';
      if (!magicOk) throw new Error(`${m.name} : ce n'est pas un vrai fichier ${isVideo ? 'vidéo' : 'image'}`);
      let check = '';
      if (isVideo) {
        const p = await probe(new Uint8Array(await blob.arrayBuffer()), 'mp4');
        if (!p.video || p.duration <= 0) throw new Error(`${m.name} : vidéo illisible (ffmpeg)`);
        if (m.kind === 'merge' && !p.audio) throw new Error(`${m.name} : le son manque après assemblage`);
        if (m.height && p.video.h !== m.height && p.video.w !== m.height) throw new Error(`${m.name} : qualité ${p.video.h}p au lieu de ${m.height}p`);
        const b = await browserCheck(blob, true);
        check = `${p.video.w}×${p.video.h}, ${p.duration.toFixed(1)} s, son ${p.audio ? 'oui' : 'non'}` + (b.ok ? ' — vérifié 2 méthodes' : ' — vérifié 1 méthode (ffmpeg), Chrome ne lit pas ce codec');
      } else {
        const b = await browserCheck(blob, false);
        if (!b.ok) throw new Error(`${m.name} : image illisible`);
        check = `${b.w}×${b.h}`;
      }

      const mb = (blob.size / 1048576).toFixed(1);
      await saveLocal(blob, m.name);
      say(`Envoi sur Trello ${i}/${job.media.length} (${mb} Mo)…`);
      try {
        const att = await trello(`/cards/${card.id}/attachments`, fd({ file: [blob, m.name], name: m.name, mimeType: m.mime }), dsc);
        if (att.bytes !== blob.size) throw new Error('taille différente sur Trello');
        expected.push({ name: m.name, bytes: blob.size });
        lines.push(`${isVideo ? '🎬' : '🖼'} ${m.name} (${mb} Mo, ${check})`);
      } catch (e) {
        lines.push(`⚠️ ${m.name} (${mb} Mo, ${check}) PAS sur Trello : ${e.status === 413 || /large|size/i.test(e.message) ? 'trop lourd pour Trello' : e.message} — gardé dans Téléchargements/catalogue-trello`);
      }
    }
  }

  // ---- contrôle final, relu sur Trello ----
  const r = await fetch(`${TRELLO}/cards/${card.id}/attachments?fields=name,bytes,isUpload`, { credentials: 'include' });
  const atts = await r.json();
  const missing = expected.filter((e) => !atts.some((a) => a.isUpload && a.bytes === e.bytes));
  if (missing.length) throw new Error('relu sur Trello : manque ' + missing.map((x) => x.name).join(', '));
  return `✅ Carte créée et relue sur Trello : ${lines.join(' · ')}`;
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.target !== 'offscreen' || m.type !== 'job') return;
  runJob(m)
    .then((report) => chrome.runtime.sendMessage({ type: 'done', jobId: m.jobId, result: { ok: true, report } }))
    .catch((e) => chrome.runtime.sendMessage({ type: 'done', jobId: m.jobId, result: { ok: false, error: String(e.message || e) } }));
});

// Accès pour les tests automatiques
self.__catTest = { merge, probe, browserCheck };

// ===== Robot « À tester → Drive » : média d'origine d'une publication Instagram → Drive =====
const IG_APP = '936619743392459';
function igPick(m) {
  const prog = (m.video_versions || []).slice().sort((a, b) => b.height - a.height)[0];
  let v = null, a = null;
  if (m.video_dash_manifest) {
    const d = new DOMParser().parseFromString(m.video_dash_manifest, 'text/xml');
    const reps = [...d.querySelectorAll('Representation')].map((r) => ({
      mime: r.getAttribute('mimeType') || r.parentNode.getAttribute('mimeType') || '',
      codecs: r.getAttribute('codecs') || r.parentNode.getAttribute('codecs') || '',
      h: +r.getAttribute('height') || 0, bw: +r.getAttribute('bandwidth') || 0, url: r.querySelector('BaseURL')?.textContent,
    })).filter((x) => x.url);
    v = reps.filter((x) => x.mime.startsWith('video')).sort((x, y) => y.h - x.h || (y.codecs.startsWith('avc') - x.codecs.startsWith('avc')) || y.bw - x.bw)[0];
    a = reps.filter((x) => x.mime.startsWith('audio')).sort((x, y) => y.bw - x.bw)[0];
  }
  if (v && a && (!prog || v.h > prog.height)) return { kind: 'merge', videoUrl: v.url, audioUrl: a.url, height: v.h };
  if (prog) return { kind: 'file', url: prog.url, height: prog.height };
  return null;
}
const toB64 = async (blob) => { const u = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
async function driveCall(url, body) {
  const r = await fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) });
  const t = await r.text(); try { return JSON.parse(t); } catch (e) { throw new Error('Drive : réponse illisible (' + r.status + ')'); }
}
async function igToDrive({ postUrl, model, prefix, driveUrl }) {
  const code = (postUrl.match(/\/(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/) || [])[1];
  if (!code) throw new Error('lien Instagram illisible');
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let id = 0n; for (const c of code.slice(0, 11)) id = id * 64n + BigInt(A.indexOf(c));
  const r = await fetch(`https://www.instagram.com/api/v1/media/${id}/info/`, { credentials: 'include', headers: { 'X-IG-App-ID': IG_APP } });
  if (r.status === 429) throw Object.assign(new Error('Instagram : trop de demandes, on réessaie plus tard'), { retry: true });
  if (!r.ok) throw new Error('Instagram a répondu ' + r.status + ' (connecte-toi à Instagram dans Chrome)');
  const it = (await r.json()).items?.[0]; if (!it) throw new Error('publication introuvable');
  const items = it.media_type === 8 ? it.carousel_media || [] : [it];
  const sent = [];
  let i = 0;
  for (const m of items) {
    i++;
    const n = items.length > 1 ? `_${i}` : '';
    let blob, name, mime;
    if (m.media_type === 2) {
      const p = igPick(m); if (!p) throw new Error('vidéo introuvable');
      if (p.kind === 'merge') { const [v, a] = await Promise.all([getBlob(p.videoUrl), getBlob(p.audioUrl)]); blob = await merge(v, a); }
      else blob = await getBlob(p.url);
      name = `${prefix}${n}.mp4`; mime = 'video/mp4';
      // vérification du fichier avant envoi (2 méthodes)
      const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
      if (String.fromCharCode(...head.slice(4, 8)) !== 'ftyp') throw new Error(name + ' : pas un vrai mp4');
      const pr = await probe(new Uint8Array(await blob.arrayBuffer()), 'mp4');
      if (!pr.video || pr.duration <= 0) throw new Error(name + ' : vidéo illisible');
      if (p.kind === 'merge' && !pr.audio) throw new Error(name + ' : le son manque');
    } else {
      const c = (m.image_versions2?.candidates || []).slice().sort((a, b) => b.width - a.width)[0];
      if (!c) continue;
      blob = await getBlob(c.url); name = `${prefix}${n}.jpg`; mime = 'image/jpeg';
      const bc = await browserCheck(blob, false); if (!bc.ok) throw new Error(name + ' : image illisible');
    }
    const res = await driveCall(driveUrl, { action: 'upload', model, fileName: name, mime, b64: await toB64(blob) });
    if (!res.ok) throw new Error(name + ' : ' + res.error);
    if (res.size !== blob.size) throw new Error(name + ' : taille différente dans Drive');
    sent.push({ name, size: blob.size, video: mime === 'video/mp4' });
  }
  if (!sent.length) throw new Error('rien à envoyer dans cette publication');
  return sent;
}
chrome.runtime.onMessage.addListener((m, s, sendResponse) => {
  if (m.target !== 'offscreen' || m.type !== 'igToDrive') return;
  igToDrive(m).then((sent) => sendResponse({ ok: true, sent })).catch((e) => sendResponse({ ok: false, error: String(e.message || e), retry: !!e.retry }));
  return true;
});
